package com.listerled.listerlighting;

import androidx.annotation.Keep;

@Keep
public class Class_GovtJob {

    public String jobtitle;
    public String jobdesc;

    public String jobname;
    public String jobpostname;
    public String noofpost;

    public String posteddate;
    public String admitcarddate;
    public String lastdate;
    public String examdate;

    public String agelimit;
    public String fees;
    public String education;

    public String experience;
    public String selectionprocess;

    public String officialweb;
    public String offnotflink;
    public String regnlink;
    private boolean expanded;


    public Class_GovtJob(String jobname, String jobpostname, String noofpost, String posteddate, String admitcarddate, String lastdate, String examdate, String agelimit, String fees, String education, String experience, String selectionprocess, String officialweb, String offnotflink, String regnlink, boolean expanded) {
        this.jobname = jobname;
        this.jobpostname = jobpostname;
        this.noofpost = noofpost;
        this.posteddate = posteddate;
        this.admitcarddate = admitcarddate;
        this.lastdate = lastdate;
        this.examdate = examdate;
        this.agelimit = agelimit;
        this.fees = fees;
        this.education = education;
        this.experience = experience;
        this.selectionprocess = selectionprocess;
        this.officialweb = officialweb;
        this.offnotflink = offnotflink;
        this.regnlink = regnlink;
        this.expanded = expanded;
    }

    public Class_GovtJob() {
    }

    public String getJobtitle() {
        return jobtitle;
    }

    public void setJobtitle(String jobtitle) {
        this.jobtitle = jobtitle;
    }

    public String getJobdesc() {
        return jobdesc;
    }

    public void setJobdesc(String jobdesc) {
        this.jobdesc = jobdesc;
    }

    public String getJobname() {
        return jobname;
    }

    public void setJobname(String jobname) {
        this.jobname = jobname;
    }

    public String getJobpostname() {
        return jobpostname;
    }

    public void setJobpostname(String jobpostname) {
        this.jobpostname = jobpostname;
    }

    public String getNoofpost() {
        return noofpost;
    }

    public void setNoofpost(String noofpost) {
        this.noofpost = noofpost;
    }

    public String getPosteddate() {
        return posteddate;
    }

    public void setPosteddate(String posteddate) {
        this.posteddate = posteddate;
    }

    public String getAdmitcarddate() {
        return admitcarddate;
    }

    public void setAdmitcarddate(String admitcarddate) {
        this.admitcarddate = admitcarddate;
    }

    public String getLastdate() {
        return lastdate;
    }

    public void setLastdate(String lastdate) {
        this.lastdate = lastdate;
    }

    public String getExamdate() {
        return examdate;
    }

    public void setExamdate(String examdate) {
        this.examdate = examdate;
    }

    public String getAgelimit() {
        return agelimit;
    }

    public void setAgelimit(String agelimit) {
        this.agelimit = agelimit;
    }

    public String getFees() {
        return fees;
    }

    public void setFees(String fees) {
        this.fees = fees;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getSelectionprocess() {
        return selectionprocess;
    }

    public void setSelectionprocess(String selectionprocess) {
        this.selectionprocess = selectionprocess;
    }

    public String getOfficialweb() {
        return officialweb;
    }

    public void setOfficialweb(String officialweb) {
        this.officialweb = officialweb;
    }

    public String getOffnotflink() {
        return offnotflink;
    }

    public void setOffnotflink(String offnotflink) {
        this.offnotflink = offnotflink;
    }

    public String getRegnlink() {
        return regnlink;
    }

    public void setRegnlink(String regnlink) {
        this.regnlink = regnlink;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }
}
