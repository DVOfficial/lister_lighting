package com.listerled.listerlighting;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class AllProductsActivity extends AppCompatActivity {


    adaptor_QueryJobsDrive registerAdaptorGovt,registerAdaptorGovtHi;

    RecyclerView recyclerView,recyclerViewHi;
    List<Class_GovtJob> listNew;
    SwipeRefreshLayout swipeRefreshLayout;

    DatabaseReference refGovtForm, refAdminGovtForm,refGovtFormHi, refAdminGovtFormHi;
    Class_GovtJob userGovtFormHi;
    class_UserData userGovtForm;
    List<Class_GovtJob> listNewHi;

    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    FirebaseUser currentUser = firebaseAuth.getCurrentUser();
    TextView username_tv;
    String rName,rPhoneno,desc;
    SearchView searchView;
    String userID= Objects.requireNonNull(currentUser).getUid();
    String userEmailID= Objects.requireNonNull(currentUser).getEmail();
    DatabaseReference refGovtNotify,refGovtNotifyHi;


    ProgressDialog notifyPB;

    //Bottom FAB
    FloatingActionButton fab_msz, fab1_WhatsApp, fab2_FBMsz, fab3_TextMsz, fab4_Gmail;
    Boolean isFABOpen = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allproducts);


//        loadLocale();
//        // adViewBanner();
//        bottomNav();
//        notifyPB();

        //interstitialAdBuild(desc);


        String user = currentUser.getEmail();
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LoginActivity.class));
            this.finish();
        }

        recyclerView = findViewById(R.id.rv_govtjob);
//        recyclerViewHi = findViewById(R.id.rv_govtjobHi);
        searchView = findViewById(R.id.quesSearchView);
        swipeRefreshLayout=findViewById(R.id.swipeRV);

//        refGovtNotify = FirebaseDatabase.getInstance().getReference().child("Addition").child("GovtJobAll");
//        refGovtNotifyHi = FirebaseDatabase.getInstance().getReference().child("Addition").child("GovtJobAll-Hindi");

        Calendar calenderCC = Calendar.getInstance();
        SimpleDateFormat simpleDateFormatCC = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
        final String dateTimeCC = simpleDateFormatCC.format(calenderCC.getTime());

        SharedPreferences sp = getSharedPreferences("LanguageSettings", MODE_PRIVATE);
        String rLang = sp.getString("MyLanguage", "");

//        if (rLang.equals("hi")) {
//            recyclerView.setVisibility(View.VISIBLE);
//
//            listNewHi = new ArrayList<>();
//            recyclerView.setLayoutManager(new LinearLayoutManager(govt_AllJobs_drive.this));
//            registerAdaptorGovtHi = new adaptor_QueryJobsDrive(this, listNewHi);
//            recyclerView.setAdapter(registerAdaptorGovtHi);
//
//            if (searchView != null) {
//                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//                    @Override
//                    public boolean onQueryTextSubmit(String query) {
//                        return false;
//                    }
//
//                    @Override
//                    public boolean onQueryTextChange(String newText) {
//                        searchHi(newText);
//                        return false;
//                    }
//                });
//            }
//
//            registerAdaptorGovtHi.setOnItemClickListener(new adaptor_QueryJobsDrive.OnItemClickListener() {
//                @Override
//                public void onItemClick(int position, String Title) {
//                    //SubmitReq(dateTimeCC,userID,userEmailID,Title);
//                    VerifyDialogET(userEmailID, userID, dateTimeCC, Title);
//                    //interstitialAD(Desc);
//                }
//
//                @Override
//                public void shareQues(int position, String question) {
//                    String govtjob = "Hey New Govt job Vacancy on " + question + " posted on FillFormOnline App.To get more Updates Click to Download the APP";
//                    generateLink(govtjob);
//                }
//
//                //                @Override
////                public void fillbyOfficialLink(int position, String offWeb) {
////
////                    Intent intent1hi=new Intent();
////                    intent1hi.setAction(Intent.ACTION_VIEW);
////                    intent1hi.addCategory(Intent.CATEGORY_BROWSABLE);
////                    intent1hi.setData(Uri.parse(offWeb));
////                    startActivity(intent1hi);
////                }
////                @Override
////                //public void onMoreInfoClick(int position, String moreInfoLink) {
////                public void onMoreInfoClick(int position, String moreInfoLink) {
//////                    Intent intent2hi=new Intent();
//////                    intent2hi.setAction(Intent.ACTION_VIEW);
//////                    intent2hi.addCategory(Intent.CATEGORY_BROWSABLE);
//////                    intent2hi.setData(Uri.parse(moreInfoLink));
//////                    startActivity(intent2hi );
////                    Intent intent=new Intent(govt_AllJobs_drive.this, govt_AllJobs_explore.class);
////                    intent.putExtra("title",moreInfoLink);
////                    startActivity(intent);
////                }
////                @Override
////                public void shareQues(int position, String question) {
////                    String govtjob = "Hey New Govt job Vacancy on " + question + " posted on FillFormOnline App.To get more Updates Click to Download the APP";
////                    generateLink(govtjob);
////                }
//
//                @Override
//                public void onMoreInfoClick(int position, String offWeb, String offnotflink, String moreInfoLink,
//                                            String jobName, String jobPostName, String jobNoOfPost,
//                                            String jobAgeLimit, String jobFees, String jobEduReq, String jobExpReq, String jobSelProc,
//                                            String reglastd, String jobPostDate, String examdate, String admitcdate) {
//                    Intent intent = new Intent(govt_AllJobs_drive.this, govt_AllJobs_explore.class);
//                    Bundle bundle = new Bundle();
//                    bundle.putString("jobName", jobName);
//                    bundle.putString("jobPostName", jobPostName);
//                    bundle.putString("jobNoOfPost", jobNoOfPost);
//
//                    bundle.putString("jobAgeLimit", jobAgeLimit);
//                    bundle.putString("jobFees", jobFees);
//                    bundle.putString("jobEduReq", jobEduReq);
//                    bundle.putString("jobExpReq", jobExpReq);
//                    bundle.putString("jobSelProc", jobSelProc);
//
//                    bundle.putString("jobofficialweb", offWeb);
//                    bundle.putString("jobOfficialNoti", offnotflink);
//                    bundle.putString("jobRegLink", moreInfoLink);
//                    bundle.putString("jobPostD", jobPostDate);
//                    bundle.putString("jobLastDate", reglastd);
//                    bundle.putString("jobExamDate", examdate);
//                    bundle.putString("jobAdmitCDate", admitcdate);
//                    intent.putExtras(bundle);
//                    startActivity(intent);
//
//                }
//            });
//
//            if (InternetConnection.checkConnection(getApplicationContext())) {
//                new GetDataTaskHin().execute();
//            } else {
//                Toast.makeText(this, "Internet Connection Not Available", Toast.LENGTH_SHORT).show();
//            }
//
//            swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//                @Override
//                public void onRefresh() {
//                    // cancel the Visual indication of a refresh
//                    swipeRefreshLayout.setRefreshing(false);
//                    new GetDataTaskHin().execute();
//
//
//                }
//            });
//        }
//        else {
            recyclerView.setVisibility(View.VISIBLE);

            listNew = new ArrayList<>();
            recyclerView.setLayoutManager(new LinearLayoutManager(AllProductsActivity.this));
            registerAdaptorGovt = new adaptor_QueryJobsDrive(this, listNew);
            recyclerView.setAdapter(registerAdaptorGovt);

            if (searchView != null) {
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        return false;
                    }
                    @Override
                    public boolean onQueryTextChange(String newText) {
                        search(newText);
                        return false;
                    }
                });
            }

            registerAdaptorGovt.setOnItemClickListener(new adaptor_QueryJobsDrive.OnItemClickListener() {
                @Override
                public void onItemClick(int position, String Title) {
                    //SubmitReq(dateTimeCC,userID,userEmailID,Title);
                    VerifyDialogET(userEmailID, userID, dateTimeCC, Title);
                    //interstitialAD(Desc);
                }

                @Override
                public void shareQues(int position, String question) {
                    String govtjob = "Hey New Govt job Vacancy on " + question + " posted on FillFormOnline App.To get more Updates Click to Download the APP";
//                    generateLink(govtjob);
                }

                //                @Override
//                public void fillbyOfficialLink(int position, String offWeb) {
//
//                    Intent intent1hi=new Intent();
//                    intent1hi.setAction(Intent.ACTION_VIEW);
//                    intent1hi.addCategory(Intent.CATEGORY_BROWSABLE);
//                    intent1hi.setData(Uri.parse(offWeb));
//                    startActivity(intent1hi);
//                }
//                @Override
//                //public void onMoreInfoClick(int position, String moreInfoLink) {
//                public void onMoreInfoClick(int position, String moreInfoLink) {
////                    Intent intent2hi=new Intent();
////                    intent2hi.setAction(Intent.ACTION_VIEW);
////                    intent2hi.addCategory(Intent.CATEGORY_BROWSABLE);
////                    intent2hi.setData(Uri.parse(moreInfoLink));
////                    startActivity(intent2hi);
//                    Intent intent=new Intent(govt_AllJobs_drive.this, govt_AllJobs_explore.class);
//                    intent.putExtra("title",moreInfoLink);
//                    startActivity(intent);
//                }
//                @Override
//                public void shareQues(int position, String question) {
//                    String govtjob = "Hey New Govt job Vacancy on " + question + " posted on FillFormOnline App.To get more Updates Click to Download the APP";
//                    generateLink(govtjob);
//                }

                @Override
                public void onMoreInfoClick(int position, String offWeb, String offnotflink, String moreInfoLink,
                                            String jobName, String jobPostName, String jobNoOfPost,
                                            String jobAgeLimit, String jobFees, String jobEduReq, String jobExpReq, String jobSelProc,
                                            String reglastd, String jobPostDate, String examdate, String admitcdate) {

                    Intent intent = new Intent(AllProductsActivity.this, ProductDetails.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("jobName", jobName);
                    bundle.putString("jobPostName", jobPostName);
                    bundle.putString("jobNoOfPost", jobNoOfPost);

                    bundle.putString("jobAgeLimit", jobAgeLimit);
                    bundle.putString("jobFees", jobFees);
                    bundle.putString("jobEduReq", jobEduReq);
                    bundle.putString("jobExpReq", jobExpReq);
                    bundle.putString("jobSelProc", jobSelProc);

                    bundle.putString("jobofficialweb", offWeb);
                    bundle.putString("jobOfficialNoti", offnotflink);
                    bundle.putString("jobRegLink", moreInfoLink);
                    bundle.putString("jobPostD", jobPostDate);
                    bundle.putString("jobLastDate", reglastd);
                    bundle.putString("jobExamDate", examdate);
                    bundle.putString("jobAdmitCDate", admitcdate);
                    intent.putExtras(bundle);
                    startActivity(intent);

                }
            });

            if (InternetConnection.checkConnection(getApplicationContext())) {
                new GetDataTaskEng().execute();
            } else {
                Toast.makeText(this, "Internet Connection Not Available", Toast.LENGTH_SHORT).show();
            }
            swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    // cancel the Visual indication of a refresh
                    swipeRefreshLayout.setRefreshing(false);
                    new GetDataTaskEng().execute();
                }
            });

//            ChildEventListener childEventListener = new ChildEventListener() {
//                @Override
//                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
//                    if(dataSnapshot.exists() && dataSnapshot.hasChildren()){
//                        userGovtForm = dataSnapshot.getValue(Class_GovtJob.class);
//                        listNew.add(userGovtForm);
//                        registerAdaptorGovt.notifyDataSetChanged();
//                        notifyPB.dismiss();
//                    }
//                    else
//                    {
//                        finish();
//                        notifyPB.dismiss();
//                    }
//                }
//                @Override
//                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
//                }
//                @Override
//                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
//                }
//                @Override
//                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
//                }
//                @Override
//                public void onCancelled(@NonNull DatabaseError databaseError) {
//                }
//            };
//            //refAdmin.addChildEventListener(childEventListener);
//            refGovtNotify.addChildEventListener(childEventListener);

//        }
        }
//    }

    class GetDataTaskEng extends AsyncTask<Void, Void, Void> {

        ProgressDialog dialogEng;
        int jIndexEng;
        int xEng;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            /**
             * Progress Dialog for User Interaction
             */

//            x=list.size();
//
//            if(x==0)
//                jIndex=0;
//            else
//                jIndex=x;

            dialogEng = new ProgressDialog(AllProductsActivity.this);
            dialogEng.setTitle("Wait Please...");
            dialogEng.setMessage("Loading All Jobs");
            dialogEng.show();
        }

        @Nullable
        @Override
        protected Void doInBackground(Void... params) {
            /**
             * Getting JSON Object from Web Using okHttp
             */
            JSONObject jsonObject = JSONParser.getDataFromWeb();
            try {
                /**
                 * Check Whether Its NULL???
                 */
                if (jsonObject != null) {
                    /**
                     * Check Length...
                     */
                    if(jsonObject.length() > 0) {
                        /**
                         * Getting Array named "contacts" From MAIN Json Object
                         */
                        JSONArray array = jsonObject.getJSONArray(Keys.KEY_CONTACTS);

                        /**
                         * Check Length of Array...
                         */
                        int lenArray = array.length();
                        if(lenArray > 0) {
                            for( ; jIndexEng < lenArray; jIndexEng++) {
                                /**
                                 * Creating Every time New Object
                                 * and
                                 * Adding into List
                                 */
//                                MyDataModel model = new MyDataModel();
                                Class_GovtJob Class_GovtJob=new Class_GovtJob();
                                /**
                                 * Getting Inner Object from contacts array...
                                 * and
                                 * From that We will get Name of that Contact
                                 *
                                 */
                                JSONObject innerObject = array.getJSONObject(jIndexEng);

                                String jobTitle = innerObject.getString(Keys.KEY_JOBTITLEC);
                                String jobDesc = innerObject.getString(Keys.KEY_JOBDESC);

                                String jobName = innerObject.getString(Keys.KEY_JOBCNAME);
                                String jobPostName = innerObject.getString(Keys.KEY_JOBPOSTNAME);
                                String jobNoOfPost = innerObject.getString(Keys.KEY_JOBNOOFPOST);

                                String jobAgeLimit = innerObject.getString(Keys.KEY_JOBAGEL);
                                String jobFees = innerObject.getString(Keys.KEY_JOBFEES);
                                String jobEduReq = innerObject.getString(Keys.KEY_JOBEDUREQ);
                                String jobExpReq = innerObject.getString(Keys.KEY_JOBEXPREQ);
                                String jobSelProc = innerObject.getString(Keys.KEY_JOBSELPROC);

                                String jobPostD = innerObject.getString(Keys.KEY_JOBPOSTD);
                                String jobLastDate = innerObject.getString(Keys.KEY_JOBLDATE);
                                String jobExamDate = innerObject.getString(Keys.KEY_JOBEDATE);
                                String jobAdmitCDate = innerObject.getString(Keys.KEY_JOBACDATE);

                                String jobofficialweb = innerObject.getString(Keys.KEY_JOBOFFLINK);
                                String jobOfficialNoti = innerObject.getString(Keys.KEY_JOBNOTLINK);
                                String jobRegLink = innerObject.getString(Keys.KEY_JOBREGLINK);

                                /**
                                 * Getting Object from Object "phone"
                                 */
                                //JSONObject phoneObject = innerObject.getJSONObject(Keys.KEY_PHONE);
                                //String phone = phoneObject.getString(Keys.KEY_MOBILE);

//                                model.setName(jobTitle+jobLastDate+jobofficialweb);
//                                model.setCountry(jobDesc+jobExamDate+jobOfficialNoti);

                                Class_GovtJob.setJobtitle(jobTitle);
                                Class_GovtJob.setJobdesc(jobDesc);
                                Class_GovtJob.setJobname(jobName);
                                Class_GovtJob.setJobpostname(jobPostName);
                                Class_GovtJob.setNoofpost(jobNoOfPost);

                                Class_GovtJob.setAgelimit(jobAgeLimit);
                                Class_GovtJob.setFees(jobFees);
                                Class_GovtJob.setEducation(jobEduReq);
                                Class_GovtJob.setExperience(jobExpReq);
                                Class_GovtJob.setSelectionprocess(jobSelProc);

                                Class_GovtJob.setPosteddate(jobPostD);
                                Class_GovtJob.setLastdate(jobLastDate);
                                Class_GovtJob.setExamdate(jobExamDate);
                                Class_GovtJob.setAdmitcarddate(jobAdmitCDate);

                                Class_GovtJob.setOffnotflink(jobOfficialNoti);
                                Class_GovtJob.setOfficialweb(jobofficialweb);
                                Class_GovtJob.setRegnlink(jobRegLink);

                                /**
                                 * Adding name and phone concatenation in List...
                                 */
                                //list.add(model);
                                listNew.add(Class_GovtJob);
                            }
                        }
                    }
                }
            } catch (JSONException je) {
                Log.i(JSONParser.TAG, "" + je.getLocalizedMessage());
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialogEng.dismiss();
            /**
             * Checking if List size if more than zero then
             * Update ListView
             */
            if(listNew.size() > 0) {
                registerAdaptorGovt.notifyDataSetChanged();
            } else {
//                Snackbar.make(findViewById(R.id.parentLayout), "No Data Found", Snackbar.LENGTH_LONG).show();
                Toast.makeText(AllProductsActivity.this, "No Data Found", Toast.LENGTH_SHORT).show();
            }
        }
    }
//    class GetDataTaskHin extends AsyncTask<Void, Void, Void> {
//
//        ProgressDialog dialogEng;
//        int jIndexEng;
//        int xEng;
//
//        @Override
//        protected void onPreExecute() {
//            super.onPreExecute();
//            /**
//             * Progress Dialog for User Interaction
//             */
//
////            x=list.size();
////
////            if(x==0)
////                jIndex=0;
////            else
////                jIndex=x;
//
//            dialogEng = new ProgressDialog(AllProductsActivity.this);
//            dialogEng.setTitle("Wait Please...");
//            dialogEng.setMessage("Loading All Jobs");
//            dialogEng.show();
//        }
//
//        @Nullable
//        @Override
//        protected Void doInBackground(Void... params) {
//            /**
//             * Getting JSON Object from Web Using okHttp
//             */
//            JSONObject jsonObject = JSONParserHi.getDataFromWeb();
//            try {
//                /**
//                 * Check Whether Its NULL???
//                 */
//                if (jsonObject != null) {
//                    /**
//                     * Check Length...
//                     */
//                    if(jsonObject.length() > 0) {
//                        /**
//                         * Getting Array named "contacts" From MAIN Json Object
//                         */
//                        JSONArray array = jsonObject.getJSONArray(Keys.KEY_CONTACTSHI);
//
//                        /**
//                         * Check Length of Array...
//                         */
//                        int lenArray = array.length();
//                        if(lenArray > 0) {
//                            for( ; jIndexEng < lenArray; jIndexEng++) {
//                                /**
//                                 * Creating Every time New Object
//                                 * and
//                                 * Adding into List
//                                 */
////                                MyDataModel model = new MyDataModel();
//                                Class_GovtJob Class_GovtJob=new Class_GovtJob();
//                                /**
//                                 * Getting Inner Object from contacts array...
//                                 * and
//                                 * From that We will get Name of that Contact
//                                 *
//                                 */
//                                JSONObject innerObject = array.getJSONObject(jIndexEng);
//
//                                String jobTitle = innerObject.getString(Keys.KEY_JOBTITLEC);
//                                String jobDesc = innerObject.getString(Keys.KEY_JOBDESC);
//
//                                String jobName = innerObject.getString(Keys.KEY_JOBCNAME);
//                                String jobPostName = innerObject.getString(Keys.KEY_JOBPOSTNAME);
//                                String jobNoOfPost = innerObject.getString(Keys.KEY_JOBNOOFPOST);
//
//                                String jobAgeLimit = innerObject.getString(Keys.KEY_JOBAGEL);
//                                String jobFees = innerObject.getString(Keys.KEY_JOBFEES);
//                                String jobEduReq = innerObject.getString(Keys.KEY_JOBEDUREQ);
//                                String jobExpReq = innerObject.getString(Keys.KEY_JOBEXPREQ);
//                                String jobSelProc = innerObject.getString(Keys.KEY_JOBSELPROC);
//
//                                String jobPostD = innerObject.getString(Keys.KEY_JOBPOSTD);
//                                String jobLastDate = innerObject.getString(Keys.KEY_JOBLDATE);
//                                String jobExamDate = innerObject.getString(Keys.KEY_JOBEDATE);
//                                String jobAdmitCDate = innerObject.getString(Keys.KEY_JOBACDATE);
//
//                                String jobofficialweb = innerObject.getString(Keys.KEY_JOBOFFLINK);
//                                String jobOfficialNoti = innerObject.getString(Keys.KEY_JOBNOTLINK);
//                                String jobRegLink = innerObject.getString(Keys.KEY_JOBREGLINK);
//
//                                /**
//                                 * Getting Object from Object "phone"
//                                 */
//                                //JSONObject phoneObject = innerObject.getJSONObject(Keys.KEY_PHONE);
//                                //String phone = phoneObject.getString(Keys.KEY_MOBILE);
//
////                                model.setName(jobTitle+jobLastDate+jobofficialweb);
////                                model.setCountry(jobDesc+jobExamDate+jobOfficialNoti);
//
//                                Class_GovtJob.setJobtitle(jobTitle);
//                                Class_GovtJob.setJobdesc(jobDesc);
//                                Class_GovtJob.setJobname(jobName);
//                                Class_GovtJob.setJobpostname(jobPostName);
//                                Class_GovtJob.setNoofpost(jobNoOfPost);
//
//                                Class_GovtJob.setAgelimit(jobAgeLimit);
//                                Class_GovtJob.setFees(jobFees);
//                                Class_GovtJob.setEducation(jobEduReq);
//                                Class_GovtJob.setExperience(jobExpReq);
//                                Class_GovtJob.setSelectionprocess(jobSelProc);
//
//                                Class_GovtJob.setPosteddate(jobPostD);
//                                Class_GovtJob.setLastdate(jobLastDate);
//                                Class_GovtJob.setExamdate(jobExamDate);
//                                Class_GovtJob.setAdmitcarddate(jobAdmitCDate);
//
//                                Class_GovtJob.setOffnotflink(jobOfficialNoti);
//                                Class_GovtJob.setOfficialweb(jobofficialweb);
//                                Class_GovtJob.setRegnlink(jobRegLink);
//
//                                /**
//                                 * Adding name and phone concatenation in List...
//                                 */
//                                //list.add(model);
//                                listNewHi.add(Class_GovtJob);
//                            }
//                        }
//                    }
//                }
//            } catch (JSONException je) {
//                Log.i(JSONParser.TAG, "" + je.getLocalizedMessage());
//            }
//            return null;
//        }
//
//        @Override
//        protected void onPostExecute(Void aVoid) {
//            super.onPostExecute(aVoid);
//            dialogEng.dismiss();
//            /**
//             * Checking if List size if more than zero then
//             * Update ListView
//             */
//            if(listNewHi.size() > 0) {
//                registerAdaptorGovtHi.notifyDataSetChanged();
//            } else {
////                Snackbar.make(findViewById(R.id.parentLayout), "No Data Found", Snackbar.LENGTH_LONG).show();
//                Toast.makeText(govt_AllJobs_drive.this, "No Data Found", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }

//    class GetDataTaskHi extends AsyncTask<Void, Void, Void> {
//        ProgressDialog dialogHi;
//        int jIndexHi;
//        int xHi;
//
//        @Override
//        protected void onPreExecute() {
//            super.onPreExecute();
//            /**
//             * Progress Dialog for User Interaction
//             */
//
////            x=list.size();
////
////            if(x==0)
////                jIndex=0;
////            else
////                jIndex=x;
//
//            dialogHi = new ProgressDialog(govt_AllJobs_drive.this);
//            dialogHi.setTitle("Wait Please...");
//            dialogHi.setMessage("Loading All Jobs");
//            dialogHi.show();
//        }
//
//        @Nullable
//        @Override
//        protected Void doInBackground(Void... params) {
//            /**
//             * Getting JSON Object from Web Using okHttp
//             */
//            JSONObject jsonObject = JSONParserHi.getDataFromWeb();
//            try {
//                /**
//                 * Check Whether Its NULL???
//                 */
//                if (jsonObject != null) {
//                    /**
//                     * Check Length...
//                     */
//                    if(jsonObject.length() > 0) {
//                        /**
//                         * Getting Array named "contacts" From MAIN Json Object
//                         */
//                        JSONArray array = jsonObject.getJSONArray(KeysHI.KEY_CONTACTSHI);
//
//                        /**
//                         * Check Length of Array...
//                         */
//                        int lenArray = array.length();
//                        if(lenArray > 0) {
//                            for( ; jIndexHi < lenArray; jIndexHi++) {
//                                /**
//                                 * Creating Every time New Object
//                                 * and
//                                 * Adding into List
//                                 */
////                                MyDataModel model = new MyDataModel();
//                                Class_GovtJob Class_GovtJob=new Class_GovtJob();
//                                /**
//                                 * Getting Inner Object from contacts array...
//                                 * and
//                                 * From that We will get Name of that Contact
//                                 *
//                                 */
//                                JSONObject innerObject = array.getJSONObject(jIndexHi);
//
//                                String jobTitle = innerObject.getString(KeysHI.KEY_JOBTITLEC);
//                                String jobDesc = innerObject.getString(KeysHI.KEY_JOBDESC);
//
//                                String jobName = innerObject.getString(KeysHI.KEY_JOBCNAME);
//                                String jobPostName = innerObject.getString(KeysHI.KEY_JOBPOSTNAME);
//                                String jobNoOfPost = innerObject.getString(KeysHI.KEY_JOBNOOFPOST);
//
//                                String jobAgeLimit = innerObject.getString(KeysHI.KEY_JOBAGEL);
//                                String jobFees = innerObject.getString(KeysHI.KEY_JOBFEES);
//                                String jobEduReq = innerObject.getString(KeysHI.KEY_JOBEDUREQ);
//                                String jobExpReq = innerObject.getString(KeysHI.KEY_JOBEXPREQ);
//                                String jobSelProc = innerObject.getString(KeysHI.KEY_JOBSELPROC);
//
//                                String jobPostD = innerObject.getString(KeysHI.KEY_JOBPOSTD);
//                                String jobLastDate = innerObject.getString(KeysHI.KEY_JOBLDATE);
//                                String jobExamDate = innerObject.getString(KeysHI.KEY_JOBEDATE);
//                                String jobAdmitCDate = innerObject.getString(KeysHI.KEY_JOBACDATE);
//
//                                String jobofficialweb = innerObject.getString(KeysHI.KEY_JOBOFFLINK);
//                                String jobOfficialNoti = innerObject.getString(KeysHI.KEY_JOBNOTLINK);
//                                String jobRegLink = innerObject.getString(KeysHI.KEY_JOBREGLINK);
//
//                                /**
//                                 * Getting Object from Object "phone"
//                                 */
//                                //JSONObject phoneObject = innerObject.getJSONObject(Keys.KEY_PHONE);
//                                //String phone = phoneObject.getString(Keys.KEY_MOBILE);
//
////                                model.setName(jobTitle+jobLastDate+jobofficialweb);
////                                model.setCountry(jobDesc+jobExamDate+jobOfficialNoti);
//
//                                Class_GovtJob.setJobtitle(jobTitle);
//                                Class_GovtJob.setJobdesc(jobDesc);
//                                Class_GovtJob.setJobname(jobName);
//                                Class_GovtJob.setJobpostname(jobPostName);
//                                Class_GovtJob.setNoofpost(jobNoOfPost);
//
//                                Class_GovtJob.setAgelimit(jobAgeLimit);
//                                Class_GovtJob.setFees(jobFees);
//                                Class_GovtJob.setEducation(jobEduReq);
//                                Class_GovtJob.setExperience(jobExpReq);
//                                Class_GovtJob.setSelectionprocess(jobSelProc);
//
//                                Class_GovtJob.setPosteddate(jobPostD);
//                                Class_GovtJob.setLastdate(jobLastDate);
//                                Class_GovtJob.setExamdate(jobExamDate);
//                                Class_GovtJob.setAdmitcarddate(jobAdmitCDate);
//
//                                Class_GovtJob.setOffnotflink(jobOfficialNoti);
//                                Class_GovtJob.setOfficialweb(jobofficialweb);
//                                Class_GovtJob.setRegnlink(jobRegLink);
//
//                                /**
//                                 * Adding name and phone concatenation in List...
//                                 */
//                                //list.add(model);
//                                listNewHi.add(Class_GovtJob);
//                            }
//                        }
//                    }
//                }
//            } catch (JSONException je) {
//                Log.i(JSONParserHi.TAG, "" + je.getLocalizedMessage());
//            }
//            return null;
//        }
//
//        @Override
//        protected void onPostExecute(Void aVoid) {
//            super.onPostExecute(aVoid);
//            dialogHi.dismiss();
//            /**
//             * Checking if List size if more than zero then
//             * Update ListView
//             */
//            if(listNewHi.size() > 0) {
//                registerAdaptorGovtHi.notifyDataSetChanged();
//                Toast.makeText(govt_AllJobs_drive.this, "Data Found Hindi", Toast.LENGTH_SHORT).show();
//
//            } else {
////                Snackbar.make(findViewById(R.id.parentLayout), "No Data Found", Snackbar.LENGTH_LONG).show();
//                Toast.makeText(govt_AllJobs_drive.this, "No Data Found", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }

//    private void notifyPB() {
//        notifyPB=new ProgressDialog(govt_AllJobs_drive.this);
//        notifyPB.setTitle("Welcome");
//        notifyPB.setMessage("Loading All Govt Jobs");
//        notifyPB.setCanceledOnTouchOutside(true);
//        notifyPB.show();
//
//    }

    //private void adViewBanner() {
//        MobileAds.initialize(this, new OnInitializationCompleteListener() {
//            @Override
//            public void onInitializationComplete(InitializationStatus initializationStatus) {
//            }
//        });
//        AdView mAdView;
//        mAdView = new AdView(this);
//        mAdView.setAdSize(AdSize.BANNER);
//        mAdView.setAdUnitId("ca-app-pub-4564671643419900/1025692621");
//        mAdView = findViewById(R.id.adView);
//        AdRequest adRequest = new AdRequest.Builder().build();
//        mAdView.loadAd(adRequest);
//        mAdView.setAdListener(new AdListener() {
//            @Override
//            public void onAdLoaded() {
//                // Code to be executed when an ad finishes loading.
//            }
//            @Override
//            public void onAdFailedToLoad(int errorCode) {
//                // Code to be executed when an ad request fails.
//            }
//            @Override
//            public void onAdOpened() {
//                // Code to be executed when an ad opens an overlay that
//                // covers the screen.
//            }
//            @Override
//            public void onAdClicked() {
//                // Code to be executed when the user clicks on an ad.
//            }
//            @Override
//            public void onAdLeftApplication() {
//                // Code to be executed when the user has left the app.
//            }
//            @Override
//            public void onAdClosed() {
//                // Code to be executed when the user is about to return
//                // to the app after tapping on an ad.
//            }
//        });
//    }
    //functionfor bottom navigation
//    public void bottomNav() {
//        //Bottom fab icons
//        fab_msz = findViewById(R.id.fab_Chats);
//        fab1_WhatsApp = findViewById(R.id.fab_WhatsApp);
//        fab2_FBMsz = findViewById(R.id.fab_FBMessenger);
//        fab3_TextMsz = findViewById(R.id.fab_TextMsz);
//        fab4_Gmail = findViewById(R.id.fab_Gmail);
////Bottom fab icons animation
//        bottom_FABAnimation.init(fab1_WhatsApp);
//        bottom_FABAnimation.init(fab2_FBMsz);
//        bottom_FABAnimation.init(fab3_TextMsz);
//        bottom_FABAnimation.init(fab4_Gmail);
////Bottom fab icons listener
//        fab_msz.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                animateFab();
//            }
//        });
//        fab1_WhatsApp.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(govt_AllJobs_drive.this, "Whatsapp Opening", Toast.LENGTH_LONG).show();
//                animateFab();
//                openWhatsapp();
//            }
//        });
//        fab2_FBMsz.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(govt_AllJobs_drive.this, "FB Messager Opening", Toast.LENGTH_LONG).show();
//                animateFab();
//                openFBApp();
//            }
//        });
//        fab3_TextMsz.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(govt_AllJobs_drive.this, "Message App opening", Toast.LENGTH_LONG).show();
//                animateFab();
//                openSMSApp();
//            }
//        });
//        fab4_Gmail.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(govt_AllJobs_drive.this, "Gmail App Opening", Toast.LENGTH_LONG).show();
//                animateFab();
//                openGmailApp();
//            }
//        });
//        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nav_view);
//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                switch (item.getItemId()) {
//                    case R.id.action_Home:
//                        startActivity( new Intent( govt_AllJobs_drive.this, landing_Page.class ) );
//                        Toast.makeText(govt_AllJobs_drive.this, "HomePage", Toast.LENGTH_LONG).show();
//                        break;
//                    case R.id.action_Notifications:
//                        Toast.makeText(govt_AllJobs_drive.this, "Notifications & Favorites", Toast.LENGTH_LONG).show();
//                        startActivity( new Intent( govt_AllJobs_drive.this, user_Notification.class ) );
//                        break;
//                    case R.id.action_Settings:
//                        Toast.makeText(govt_AllJobs_drive.this, "Settings", Toast.LENGTH_LONG).show();
//                        startActivity( new Intent( govt_AllJobs_drive.this, user_Settings.class ) );
//                        break;
//                    case R.id.action_Profile:
//                        Toast.makeText(govt_AllJobs_drive.this, "User Profile", Toast.LENGTH_LONG).show();
//                        startActivity( new Intent( govt_AllJobs_drive.this, user_Profile.class ) );
//                        break;
//                    case R.id.action_Share:
//                        Toast.makeText(govt_AllJobs_drive.this, "Refer and Earn", Toast.LENGTH_LONG).show();
//                        String Title="Refer and Earn";
//                        generateLink(Title);
//                        break;
//                }
//                return true;
//            }
//        });
////end bottom nav drawer
//
//    }
//    //Fab Animation
//    private void animateFab() {
//        isFABOpen = bottom_FABAnimation.rotatefab(fab_msz, !isFABOpen);
//        if (isFABOpen) {
//            bottom_FABAnimation.fabOpen(fab1_WhatsApp);
//            bottom_FABAnimation.fabOpen(fab2_FBMsz);
//            bottom_FABAnimation.fabOpen(fab3_TextMsz);
//            bottom_FABAnimation.fabOpen(fab4_Gmail);
//        } else {
//            bottom_FABAnimation.fabClose(fab1_WhatsApp);
//            bottom_FABAnimation.fabClose(fab2_FBMsz);
//            bottom_FABAnimation.fabClose(fab3_TextMsz);
//            bottom_FABAnimation.fabClose(fab4_Gmail);
//        }
//    }
//    //function for Watsapp opening
//    void openWhatsapp() {
//        //NOTE : please use with country code first 2digits without plus signed
//        try {
//            String mobile = "+91 9212107320";
//            String msg = "Can you tell me how I can fill the form (tell Form Name) online?";
//            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=" + mobile + "&text=" + msg)));
//        } catch (Exception e) {
//            //whatsapp app not install
//            Toast.makeText(this,
//                    "Oups!Can't open Whatsapp right now. Please try again later.",
//                    Toast.LENGTH_LONG).show();
//        }
//    }
//    //function for smsapp opening
//    void openSMSApp() {
//        try {
//            Intent smsIntent = new Intent(Intent.ACTION_VIEW);
//            smsIntent.setType("vnd.android-dir/mms-sms");
//            smsIntent.putExtra("address", "9212107320");
//            smsIntent.putExtra("sms_body", "Body of Message");
//            // smsIntent.setData(Uri.parse("sms:9212107320"));
//            startActivity(smsIntent);
//        } catch (Exception e) {
//            Toast.makeText(this,
//                    "Oups!Can't open messenger right now. Please try again later.",
//                    Toast.LENGTH_LONG).show();
//        }
//    }
//    //function for FB opening
//    void openFBApp() {
//        try {
//            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://messaging/" + 101899754870923L));
//            startActivity(i);
//        } catch (ActivityNotFoundException ex) {
//            Toast.makeText(this,
//                    "Oups!Can't open Facebook messenger right now. Please try again later.",
//                    Toast.LENGTH_LONG).show();
//        }
//    }
//    //function for GMAIL opening
//    void openGmailApp() {
//        Intent intent = new Intent(Intent.ACTION_SEND);
//        intent.setType("message/rfc822");
//        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"fillformonline@outlook.com"});
//        intent.putExtra(Intent.EXTRA_SUBJECT, "FillFormOnline_Query: Ask?" );
//        intent.setPackage("com.google.android.gm");
//        if (intent.resolveActivity(getPackageManager()) != null)
//            startActivity(intent);
//        else
//            Toast.makeText(this, "Gmail App is not installed", Toast.LENGTH_LONG).show();
//    }
//    //function for App sharing
//    void appShare() {
//        Intent shareIntent = new Intent(Intent.ACTION_SEND);
//        shareIntent.setType("text/plain");
//        String body="Fill Form Online is the best App that helps user to Fill any kind of Form," +
//                "\nPlease Click on Below Link to Install:";
//        String subject="Subject";
//        String app_url = " https://play.google.com/store/apps/details?id=in.dreamworld.fillformonline";
//        shareIntent.putExtra(Intent.EXTRA_TEXT, body + app_url);
//        shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
//        startActivity(Intent.createChooser(shareIntent, "Share via"));
//    }
//    //funtion for verify Data
    public void VerifyDialogET(String email,String userid,String date,String Desc) {

        final AlertDialog dialogBuilder = new AlertDialog.Builder(this).create();
        dialogBuilder.setCanceledOnTouchOutside(false);
        //dialogBuilder.setCancelable(false);
        LayoutInflater inflater = this.getLayoutInflater();
        //interstitialAdBuild(Desc);

        View dialogView = inflater.inflate(R.layout.dialog_reqverify, null);
        TextView title=dialogView.findViewById(R.id.textView);

        final EditText inputFormRemarks = dialogView.findViewById(R.id.edt_FormRemarks);
        final EditText inputFormName = dialogView.findViewById(R.id.edt_FormName);
        inputFormName.setVisibility(View.GONE);
        Button submit = dialogView.findViewById(R.id.buttonSubmit);
        Button cancel = dialogView.findViewById(R.id.buttonCancel);

        Calendar calenderCC=Calendar.getInstance();
        SimpleDateFormat simpleDateFormatCC= new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
        final String dateTimeCC=simpleDateFormatCC.format(calenderCC.getTime());

        String TitleNew="Hi, You have selected \""+Desc+"\" Exam Form to be filled by us," +
                "\nPlease ask any Query If you have?";
        title.setText(TitleNew);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogBuilder.dismiss();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String formName,total = null;
                String formRemark = inputFormRemarks.getText().toString();

                SharedPreferences sp=getSharedPreferences("register",MODE_PRIVATE);
                if(sp.contains("Name")){
                    rName=sp.getString("Name","");
                    rPhoneno=sp.getString("Mobile","");
                }

                refGovtForm = FirebaseDatabase.getInstance().getReference().child("Landing").child("Govt Job Form");
                refAdminGovtForm = FirebaseDatabase.getInstance().getReference().child("Admin").child("Landing").child("Govt Job Form");

                userGovtForm = new class_UserData(rName,rPhoneno,email,userid,date, Desc,formRemark);
                refAdminGovtForm.push().setValue(userGovtForm);

                refGovtForm.child(date+currentUser.getUid()).setValue( Desc +"="+ formRemark );

                StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbxWMwxB5bDWFAOQNm6saNW-XY-7_ZiGQSOgLx-6ImBMCLyRcvI/exec",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                            }


                        }
                ) {
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> parmas = new HashMap<>();
                        String uuser= firebaseAuth.getUid();
                        //here we pass params
                        parmas.put("action","addItem");

                        parmas.put("Name", rName);
                        parmas.put("Mobile", rPhoneno);
                        parmas.put("EmailId",email);
                        parmas.put("UserID",userID);
                        parmas.put("Form_Name",Desc);
                        parmas.put("Form_Remarks",formRemark);
                        parmas.put("Category", "GovtJob");
                        return parmas;
                    }
                };

                int socketTimeOut = 50000;// u can change this .. here it is 50 seconds
                RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                stringRequest.setRetryPolicy(retryPolicy);

                RequestQueue queue = Volley.newRequestQueue(AllProductsActivity.this);
                queue.add(stringRequest);

                //notification
                HashMap<String,Object> map= new HashMap<>();
                map.put("admintoken","d3Lh9p0ujCVgF363cgvqC6ftJYG3");
                map.put("title",Desc);
                map.put("Description",formRemark);
                map.put("heading","GovtJob");

                DatabaseReference notification= FirebaseDatabase.getInstance().getReference()
                        .child("Notification");
                notification.child(userID).push().setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                    }
                });


                Toast.makeText(AllProductsActivity.this, "Request has been Submitted Successfully", Toast.LENGTH_LONG).show();

                dialogBuilder.dismiss();
//                interstitialAdBuild(Desc);
//                interstitialAD(Desc);

//                    startActivity(new Intent(landing_EntranceExam.this, user_Profile_UploadDoc.class));
                SubmitReq1(Desc);


            }
        });
        dialogBuilder.setView(dialogView);
        dialogBuilder.show();
    }
    //    private void interstitialAdBuild(String Desc) {
//        interstitialAd=new InterstitialAd(this);
//        //interstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
//
//        interstitialAd.setAdUnitId("ca-app-pub-4564671643419900/7698912180");
//        interstitialAd.loadAd(new AdRequest.Builder().build());
//
//        interstitialAd.setAdListener(new AdListener()
//        {
//            @Override
//            public void onAdClosed() {
//                SubmitReq1(Desc);
//
//                interstitialAd.loadAd(new AdRequest.Builder().build());
//            }
//        });
//    }
//    private void interstitialAD(String Desc) {
//        if(interstitialAd.isLoaded()){
//
//            interstitialAd.show();
//        }else{
//            SubmitReq1(Desc);
//
//        }
//
//    }
    //funtion for submit Data
    public void SubmitReq1(String data) {
        final AlertDialog dialogBuilder = new AlertDialog.Builder(this).create();

//        dialogBuilder.setCanceledOnTouchOutside(false);

        LayoutInflater inflater = this.getLayoutInflater();

        final View dialogView = inflater.inflate(R.layout.dialog_reqsubmit, null);
        TextView text=dialogView.findViewById(R.id.submitted);
        text.setText("Your Request for Exam:"+data+" has been Submitted Successfully,\nTeam will contact you shortly");

        final Button close = dialogView.findViewById(R.id.tapClose);
        final Button home = dialogView.findViewById(R.id.tapHome);

        final Button share = dialogView.findViewById(R.id.tapShare);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Title="Refer and Earn";
//                generateLink(Title);
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogBuilder.dismiss();
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( AllProductsActivity.this, Home.class ) );
                dialogBuilder.dismiss();
                finish();
            }
        });
        dialogBuilder.setView(dialogView);
        dialogBuilder.show();
    }
//    public void loadLocale(){
//        SharedPreferences prefs=getSharedPreferences("LanguageSettings", Activity.MODE_PRIVATE);
//        String Language=prefs.getString("MyLanguage","");
//        setLocale(Language);
//    }
//    public void setLocale(String language) {
//        if (language != null) {
//            Locale locale = new Locale(language);
//            Locale.setDefault(locale);
//            Configuration configuration = new Configuration();
//            configuration.locale = locale;
//            getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());
//            //save data
//
//            SharedPreferences.Editor editor = getSharedPreferences("LanguageSettings", MODE_PRIVATE).edit();
//            editor.putString("MyLanguage", language);
//            editor.commit();
//            //loadLocale();
//        }
//        else{
//            SharedPreferences.Editor editor = getSharedPreferences("LanguageSettings", MODE_PRIVATE).edit();
//            editor.putString("MyLanguage", "en");
//            editor.commit();
//
//        }
//    }
//    public void generateLink(String govtjobtitle) {
//        DynamicLink dynamicLink = FirebaseDynamicLinks.getInstance().createDynamicLink()
//                .setLink(Uri.parse("https://play.google.com/store/apps/details?id=in.dreamworld.fillformonline+"))
//                .setDomainUriPrefix("https://fillformonline.page.link")
//                // Open links with this app on Android
//                .setAndroidParameters(new DynamicLink.AndroidParameters.Builder().build())
//                // Open links with com.example.ios on iOS
//                .setIosParameters(new DynamicLink.IosParameters.Builder("in.dreamworld.fillformonline").build())
//                .buildDynamicLink();
//        Uri dynamicLinkUri = dynamicLink.getUri();
//// https://fillformonline.page.link?apn=in.dreamworld.fillformonline&ibi=in.dreamworld.fillformonline&link=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Din.dreamworld.fillformonline
//        String userEmail=currentUser.getEmail();
//        createReferLink(userEmail,"refer",govtjobtitle);
//    }
//    public void createReferLink(String userId,String ExamName,String govtjobtitle){
//        //manually link generation
//        String title="Fill Form Online-App";
//        String body=govtjobtitle;
//        String shareLinkText= "https://fillformonline.page.link/?"+
//                "link=https://play.google.com/store/apps/details?id=in.dreamworld.fillformonline+"+userId+"-"+ExamName+
//                "&apn="+getPackageName()+
//                "&st="+title+
//                "&sd="+body+
//                "&si="+ R.mipmap.ic_launcher;
////Link Shortener
//        Task<ShortDynamicLink> shortLinkTask = FirebaseDynamicLinks.getInstance().createDynamicLink()
//                //.setLongLink(dynamicLinkUri)          //firebase generated link
//                .setLongLink(Uri.parse(shareLinkText)) //manuall link
//                .buildShortDynamicLink()
//                .addOnCompleteListener(this, new OnCompleteListener<ShortDynamicLink>() {
//                    @Override
//                    public void onComplete(@NonNull Task<ShortDynamicLink> task) {
//                        if (task.isSuccessful()) {
//                            // Short link created
//                            Uri shortLink = task.getResult().getShortLink();
//                            Uri flowchartLink = task.getResult().getPreviewLink();
//                            Intent intent=new Intent();
//                            intent.setAction(Intent.ACTION_SEND);
//                            intent.putExtra(Intent.EXTRA_TEXT,shortLink.toString());
//                            intent.setType("text/plain");
//                            startActivity(intent);
//                        } else {
//                            // Error
//                            // ...
//                        }
//                    }
//                });
//    }

    public void search(String newText) {
        ArrayList<Class_GovtJob> listSearchQues=new ArrayList<>();
        for (Class_GovtJob classUserSearch:listNew){
            if (classUserSearch.getJobtitle().toLowerCase().contains(newText.toLowerCase())){
                listSearchQues.add(classUserSearch);
            }
        }
        adaptor_QueryJobsDrive adapSearchJob= new adaptor_QueryJobsDrive(this,listSearchQues);
        recyclerView.setAdapter(adapSearchJob);
    }
//    public void searchHi(String newText) {
//        ArrayList<Class_GovtJob> listSearchQuesHi=new ArrayList<>();
//        for (Class_GovtJob classUserSearchHi:listNewHi){
//            if (classUserSearchHi.getJobtitle().toLowerCase().contains(newText.toLowerCase())){
//                listSearchQuesHi.add(classUserSearchHi);
//            }
//        }
//        adaptor_QueryJobsDrive adapSearchJobHi= new adaptor_QueryJobsDrive(this,listSearchQuesHi);
//        recyclerView.setAdapter(adapSearchJobHi);
//    }

    @Override
    public void onStart() {
        super.onStart();
//        username_tv = findViewById(R.id.loginstatus);
//        // Check if user is signed in (non-null) and update UI accordingly.
//        updateUI(currentUser);
    }

//    public void  updateUI(FirebaseUser user){
//        String rName,rEmail,userName,userEmail;
//        SharedPreferences sp=getSharedPreferences("register",MODE_PRIVATE);
//        rName = sp.getString("Name", "");
//        rEmail=sp.getString("EMail","");
//        userEmail=user.getEmail();
//        userName=user.getEmail();
//        if (rEmail.equals(userEmail)){
//            userName=rName;
//        }
//        if(user != null) {
//            username_tv.setText("Hi,"+userName);
//        }else{
//            username_tv.setText("class_User not Logged In");
//        }
//    }
}