package com.listerled.listerlighting;

public class Keys {

    public static final String KEY_CONTACTS = "English";
    public static final String KEY_CONTACTSHI = "Hindi";

    public static final String KEY_JOBCNAME = "JobCName";
    public static final String KEY_JOBPOSTNAME = "PostName";
    public static final String KEY_JOBNOOFPOST = "NoofPost";

    public static final String KEY_JOBTITLEC = "JobTitleC";

    public static final String KEY_JOBAGEL = "AgeLimit";
    public static final String KEY_JOBFEES = "Fees";
    public static final String KEY_JOBEDUREQ = "EducationReq";
    public static final String KEY_JOBEXPREQ = "ExpRequired";
    public static final String KEY_JOBSELPROC = "SelectionProcess";

    public static final String KEY_JOBDESC = "JobDescription";

    public static final String KEY_JOBPOSTD = "FFO_Posted_Date";
    public static final String KEY_JOBLDATE = "LastDate";
    public static final String KEY_JOBACDATE = "AdmitCDate";
    public static final String KEY_JOBEDATE = "ExamDate";

    public static final String KEY_JOBOFFLINK = "OfficialWebsite";
    public static final String KEY_JOBNOTLINK = "NotificationLink";
    public static final String KEY_JOBREGLINK = "RegistrationLink";




}
