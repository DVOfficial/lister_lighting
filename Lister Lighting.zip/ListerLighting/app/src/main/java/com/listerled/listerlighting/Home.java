package com.listerled.listerlighting;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Home extends AppCompatActivity {

    Button logoutButton;
    TextView textView;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    BottomNavigationView bottom_Navigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        logoutButton=findViewById(R.id.logoutButton);
        textView=findViewById(R.id.textView);
        bottom_Navigation=findViewById(R.id.bottom_Navigation);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser=firebaseAuth.getCurrentUser();

        if (firebaseUser==null){
            Intent intent =new Intent(Home.this,LoginActivity.class);
            startActivity(intent);
            finish();

        }else{
        textView.setText(firebaseUser.getEmail());
        }



        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent =new Intent(Home.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        bottom_Navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.btm_home:
                        Toast.makeText(Home.this, "Home", Toast.LENGTH_SHORT).show();
                        Intent intent =new Intent(Home.this,Home.class);
                        startActivity(intent);
                        break;
                    case R.id.btm_allproduct:
                        Toast.makeText(Home.this, "All Products", Toast.LENGTH_SHORT).show();
                        intent =new Intent(Home.this,AllProductsActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.btm_query:
                        Toast.makeText(Home.this, "Fetch Query", Toast.LENGTH_SHORT).show();
                        intent =new Intent(Home.this,FetchProductDataActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.btm_profile:
                        Toast.makeText(Home.this, "Profile", Toast.LENGTH_SHORT).show();
                        intent =new Intent(Home.this,UserProfileActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.btm_settings:
                        Toast.makeText(Home.this, "Settings", Toast.LENGTH_SHORT).show();
                        intent =new Intent(Home.this,SettingActivity.class);
                        startActivity(intent);
                        break;

                }
                return true;
            }
        });
    }
}